# Presentación Beamer — Seminario I

Compilar con `pdflatex presentacion.tex` (dos veces). El PDF de vista previa se incluye.

## Origen y límites
La organización reproduce la secuencia académica observada en las dos presentaciones aportadas (JHR y JAAH): portada, jurado, agenda, objetivo, problema, objetivos, arquitectura, tecnologías, alternativas, propuesta, cronograma, conclusiones, compromisos, referencias y preguntas. El contenido técnico proviene de las Tablas 3.1 y 3.2 del usuario y de los objetivos y alcance de la tesis previamente descritos. No se inventaron estadísticas, evaluación ponderada, fechas ni integrantes del jurado.

## Logotipos oficiales
**No se han incluido archivos de logotipos oficiales** porque no se pudo descargar/verificar sus originales en este entorno. La presentación utiliza etiquetas vectoriales tipográficas provisionales, claramente diferenciadas de los logos oficiales. Para usar logos oficiales, obtenga sus archivos SVG de los sitios oficiales de cada tecnología, revise las políticas de marca, conviértalos a PDF vectorial (`inkscape logo.svg --export-filename=assets/identificador.pdf`) y guárdelos bajo estos nombres:

`kotlin.pdf`, `flutter.pdf`, `reactnative.pdf`, `dotnet.pdf`, `springboot.pdf`, `nestjs.pdf`, `django.pdf`, `mongodb.pdf`, `postgresql.pdf`, `minio.pdf`, `amazons3.pdf`, `firebase.pdf`, `huggingface.pdf`, `kaggle.pdf`.

El código los cargará automáticamente cuando existan. También admite PNG, pero se recomienda PDF vectorial. Los diagramas TikZ sí son vectoriales y ya están integrados.

## Pendientes académicos
Completar estudiante, fecha, codirector y jurado. Revisar la formulación oficial de objetivos y el alcance del análisis morfológico. Confirmar si se mantendrá MongoDB para el corpus junto con PostgreSQL para identidad. Agregar bibliografía académica del problema y metodología, además de las referencias técnicas.
